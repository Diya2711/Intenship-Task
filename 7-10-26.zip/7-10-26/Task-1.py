import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

#Load dataset
df = pd.read_csv("heart.csv")

print("Original Dataset")
print("----------------")
print("Number of rows:", len(df))
print("Number of columns:", len(df.columns))

#Custom duplicate comparison algorithm
duplicate_indexes = []
duplicate_pairs = []

for i in range(len(df)):
    for j in range(i + 1, len(df)):
        same = True

        for column in df.columns:
            if df.iloc[i][column] != df.iloc[j][column]:
                same = False
                break

        if same:
            duplicate_indexes.append(j)
            duplicate_pairs.append((i, j))
            duplicate_indexes = sorted(set(duplicate_indexes))


print("\nDuplicate Analysis")
print("------------------")
print("Duplicate rows found:", len(duplicate_indexes))

print("\nFirst 10 duplicate indexes:")
print(duplicate_indexes[:10])

#Display some duplicate records
if len(duplicate_indexes) > 0:
    print("\nSample Duplicate Records:")
    print(df.iloc[duplicate_indexes[:10]])

#Manually remove duplicates 
df_cleaned = df.drop(index=duplicate_indexes)
df_cleaned = df_cleaned.reset_index(drop=True)

print("\nAfter Removing Duplicates")
print("-------------------------")
print("Rows before:", len(df))
print("Rows after :", len(df_cleaned))
print("Rows removed:", len(df) - len(df_cleaned))

#Save clean dataset
df_cleaned.to_csv("heart_cleaned.csv", index=False)
print("\nCleaned dataset saved as: heart_cleaned.csv")

#ML before removing duplicates
X = df.drop("target", axis=1)
y = df["target"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

model_before = LogisticRegression(max_iter=1000)
model_before.fit(X_train, y_train)
prediction_before = model_before.predict(X_test)

accuracy_before = accuracy_score(y_test, prediction_before)
precision_before = precision_score(y_test, prediction_before)
recall_before = recall_score(y_test, prediction_before)
f1_before = f1_score(y_test, prediction_before)

#ML after removing duplicates
X_clean = df_cleaned.drop("target", axis=1)
y_clean = df_cleaned["target"]

X_train, X_test, y_train, y_test = train_test_split(
    X_clean, y_clean,
    test_size=0.20,
    random_state=42,
    stratify=y_clean
)

model_after = LogisticRegression(max_iter=1000)
model_after.fit(X_train, y_train)
prediction_after = model_after.predict(X_test)

accuracy_after = accuracy_score(y_test, prediction_after)
precision_after = precision_score(y_test, prediction_after)
recall_after = recall_score(y_test, prediction_after)
f1_after = f1_score(y_test, prediction_after)

#Compare results
print("\nMachine Learning Performance")
print("----------------------------")

print("\nBefore Duplicate Removal:")
print("Accuracy :", round(accuracy_before * 100, 2), "%")
print("Precision:", round(precision_before * 100, 2), "%")
print("Recall   :", round(recall_before * 100, 2), "%")
print("F1 Score :", round(f1_before * 100, 2), "%")

print("\nAfter Duplicate Removal:")
print("Accuracy :", round(accuracy_after * 100, 2), "%")
print("Precision:", round(precision_after * 100, 2), "%")
print("Recall   :", round(recall_after * 100, 2), "%")
print("F1 Score :", round(f1_after * 100, 2), "%")